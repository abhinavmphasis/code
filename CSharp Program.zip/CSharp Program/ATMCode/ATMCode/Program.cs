﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATMCode
{
    class Program
    {
      

        static void Main(string[] args)
        {
            int EnterAmount = 0;
            Console.WriteLine("Enter the amount to withdraw");
            EnterAmount = int.Parse(Console.ReadLine());
            CheckValidation(EnterAmount);             
        }

        private static void CheckValidation(int EnterAmount)
        {
            int[] currDenom = { 500, 50, 10, 5 };
            int withdrawAmount = 0;
            int a = 0;
            int rs = 0;
            int EnterAmtMod = 0; 
            for (int i = 0; i < currDenom.Length; i++)
            {
                EnterAmtMod = EnterAmount;
                if (currDenom[i] <= EnterAmtMod)
                {
                    rs = EnterAmtMod % currDenom[i];
                    withdrawAmount = EnterAmtMod - rs;
                    EnterAmtMod = EnterAmtMod - withdrawAmount;
                }
            }
            if (EnterAmtMod != 0)
            {
                Console.WriteLine("Invalid Amount");
            }
            else
            {
                for (int i = 0; i < currDenom.Length; i++)
                {

                    if (currDenom[i] <= EnterAmount)
                    {
                        a = EnterAmount / currDenom[i]; //1
                        rs = EnterAmount % currDenom[i]; //55
                        withdrawAmount = EnterAmount - rs; //500
                        Console.WriteLine("\n " + currDenom[i] + "*" + a);
                        EnterAmount = EnterAmount - withdrawAmount;
                    }
                } 
            }
        }
    }
}
